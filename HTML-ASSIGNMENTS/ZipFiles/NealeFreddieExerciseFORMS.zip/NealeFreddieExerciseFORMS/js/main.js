document
  .getElementById("contact-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;
    const subscribe = document.getElementById("subscribe").checked;

    if (subscribe) {
      alert(
        `Thank you for contacting us, ${name}! You have also been subscribed to our newsletter.`
      );
    } else {
      alert(`Thank you for contacting us, ${name}!`);
    }

    document.getElementById("contact-form").reset();
  });

function smoothScroll() {
  const navLinks = document.querySelectorAll("nav a");
  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault();
      const navHash = document.querySelector(link.hash);
      navHash.scrollIntoView({ behavior: "smooth" });
    });
  });
}

smoothScroll();
